# Overview

In this assignment, we were asked to create two classes to help implement an OOP
workflow. I implemented them as a KaggleDataManager, an object that abstracts
away the downloading and reading/loading of the data, and DataProfiler, an
object that really only exists for the purpose of this assignment, maybe a
better use of the object would be to extend the pd.DataFrame class, but I
figured I'd implement that later
