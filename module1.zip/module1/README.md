# Module 1

In this module we were tasked to:

Fetch weather data from the CSV file and store it in Python data structures.
Document your code and following naming standards and Pythonic style standards.
Generate and demonstrate online documentation. If you don't already know tools
for generating Python docs, start with the built-in tool pydoc and generate a
web page with it.

## Implementation

I ended up downloading the dataset direct from Kaggle, onto the host's computer,
and reading the data in using pandas, and writing the docs to an html file using
pydoc.
