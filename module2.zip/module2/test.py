import my_first_package_8TyUNLepm1b as mfp

mfp.test_functions()
